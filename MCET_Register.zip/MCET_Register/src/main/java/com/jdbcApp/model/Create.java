package com.jdbcApp.model;

import java.sql.*;

public class Create {
	public static void main(String args[])
	{
		DbConnector d= new DbConnector();
		Connection con=  d.db_Connect();
		try
		{
			String q="insert into student (name,email,dept) values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, "Vishnu");
			ps.setString(2, "v@gmail.com");
			ps.setString(3, "cse");
			
			int i= ps.executeUpdate();
			if(i!=0)
			{
				System.out.println("Registered Successfully");
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}

}
